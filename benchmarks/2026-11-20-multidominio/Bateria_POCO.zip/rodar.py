"""Rodar na pasta dos casos no POCO com python rodar.py. Saída incremental JSONL."""
import json, os, random, subprocess, sys, time, urllib.error, urllib.request, shutil, platform
from pathlib import Path
P=Path(__file__).resolve().parent
SEMENTE=3200
def ler(nome):
    return json.loads((P/nome).read_text())
def gravar(nome,d):
    with (P/nome).open("a") as f:
        f.write(json.dumps(d,ensure_ascii=False)+"\n")
def ja(nome):
    a=P/nome
    return {json.loads(l)["chave"] for l in a.read_text().splitlines()} if a.exists() else set()
def raciocinio():
    sys.path.insert(0,str(Path.home()/"controle-ir/capacidades/tela"))
    import piloto
    modelo="claude-sonnet-5-5"
    chave=piloto.ler_chave()
    assert chave,"API não configurada"
    casos=ler("raciocinio_casos.json")
    rng=random.Random(SEMENTE);rng.shuffle(casos)
    estrito="--schema" in sys.argv
    arquivo="sonnet_schema.jsonl" if estrito else "sonnet.jsonl"
    feitos=ja(arquivo)
    for j,c in enumerate(casos):
        for esforco in (["medium","high"] if j%2==0 else ["high","medium"]):
            if estrito and esforco!="high":continue
            k=c["id"]+"-"+esforco
            if k in feitos:continue
            corpo={"model":modelo,"max_tokens":3500,"thinking":{"type":"adaptive"},"output_config":{"effort":esforco},
                    "system":"Resolva o pedido. Responda APENAS com um objeto JSON de uma chave, resposta. Siga os tipos e formatos solicitados.",
                    "messages":[{"role":"user","content":c["pedido"]}]}
            if estrito:
                tipos=[{"type":t} for t in ("string","number","boolean","null")]
                tipos.append({"type":"array","items":{"type":"string"}})
                corpo["output_config"]["format"]={"type":"json_schema","schema":{"type":"object",
                    "properties":{"resposta":{"anyOf":tipos}},"required":["resposta"],"additionalProperties":False}}
            req=urllib.request.Request("https://api.anthropic.com/v1/messages",data=json.dumps(corpo).encode(),
                headers={"content-type":"application/json","x-api-key":chave,"anthropic-version":piloto.API_VERSAO})
            row=dict(chave=k,id=c["id"],familia=c["familia"],esforco=esforco,modelo= modelo)
            t=time.perf_counter()
            try:
                with urllib.request.urlopen(req,timeout=45) as resp:d=json.load(resp)
                txt="".join(b["text"] for b in d["content"] if b.get("type")=="text")
                row.update(texto=txt,uso=d.get("usage"),fim=d.get("stop_reason"),modelo=d.get("model",modelo))
                obj=json.loads(txt)
                obt=obj["resposta"]; esp=c["esperado"]
                row["acerto"]=d.get("stop_reason")=="end_turn" and list(obj)==["resposta"] and obt==esp and (type(esp) is type(obt) or type(esp) in (float,int) and type(obt) in (float,int))
            except Exception as exc:
                row.update(erro=type(exc).__name__+" "+str(exc)[:100],acerto=False)
            row["ms"]=round((time.perf_counter()-t)*1000,1);gravar(arquivo,row)
def xadrez():
    motor=os.environ.get("STOCKFISH","stockfish")
    p=subprocess.Popen([motor],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,bufsize=1)
    def cmd(s):p.stdin.write(s+"\n");p.stdin.flush()
    def ate(prefix):
        lines=[]
        for line in p.stdout:
            lines.append(line.strip())
            if line.startswith(prefix):return lines
        raise RuntimeError("motor encerrado")
    cmd("uci");uci=ate("uciok");nome=next(x[8:] for x in uci if x.startswith("id name "))
    cmd("setoption name Threads value 2");cmd("setoption name Hash value 64")
    casos=ler("xadrez_casos.json")
    filas=[(c,b) for c in casos for b in [50,200,500]]
    random.Random(SEMENTE).shuffle(filas);feitos=ja("xadrez.jsonl")
    for c,b in filas:
        k=c["id"]+"-"+str(b)
        if k in feitos:continue
        cmd("ucinewgame");cmd("isready");ate("readyok")
        obs=[]
        for st in c["states"]:
            cmd("position fen "+st["fen"])
            t=time.perf_counter();cmd("go movetime "+str(b));lin=ate("bestmove");dt=(time.perf_counter()-t)*1000
            lance=lin[-1].split()[1]; info=next((s.split() for s in reversed(lin[:-1]) if " nodes " in s),[])
            ok=lance==st["expected"] or lance in st["mates"]
            obs.append(dict(lance=lance,esperado=st["expected"],acerto=ok,ms=round(dt,2),nos=int(info[info.index("nodes")+1]) if info else None))
            if not ok or lance in st["mates"]:break
        gravar("xadrez.jsonl",dict(chave=k,id=c["id"],rating=c["rating"],motor=nome,orcamento=b,acerto=all(o["acerto"] for o in obs),lances=obs))
    cmd("quit");p.wait()
if __name__=="__main__":
    if "xadrez" in sys.argv or len(sys.argv)==1:xadrez()
    if "sonnet" in sys.argv or len(sys.argv)==1:raciocinio()
