"""Servidor MCP (JSON-RPC 2.0) sobre HTTP — transporte Streamable HTTP.

Responde cada POST com um único ``application/json`` (permitido pela
especificação), aceita notificações com 202 e devolve 405 para GET (sem
fluxo SSE). Não exige sessão: funciona com clientes das versões
2025-03-26, 2025-06-18, 2025-11-25 e posteriores que mantêm o mesmo
formato de ``tools/list`` e ``tools/call``.
"""
from __future__ import annotations

import json
import traceback

from . import __version__
from .servico import ErroUso, Servico

VERSOES = ["2025-11-25", "2025-06-18", "2025-03-26", "2024-11-05"]

INSTRUCOES = """Você controla o emissor infravermelho do celular do usuário (POCO/Android) por este conector.
Responda ao usuário em português.
- Antes de comandar um aparelho, chame opcoes(aparelho) para ver os parâmetros, valores aceitos e teclas.
- Pedidos compostos ("23 °C, frio, ventilação baixa") vão numa única chamada controlar com definir={...}.
- Para mudar só um valor de um perfil de estado completo, envie só esse valor: o resto é preservado do último envio.
- Se o pedido usar um recurso que o perfil não tem (ex.: oscilação), explique a limitação; não troque a escolha do usuário.
- Quando a API responder status "sinal_enviado", diga "sinal enviado" — a confirmação física vem do usuário.
- Se o usuário disser que usou o controle original, chame registrar_estado(controle_original_usado=true).
- Em "precisa_confirmacao", explique o motivo e pergunte; não reenvie sem a resposta.
- Em "parcial", diga quais etapas já saíram e não as repita.
- Descoberta: buscar inicia testes no celular. Antes, explique que Enter sozinho no Termux pausa na hora.
  Se o usuário disser "ligou"/"apitou"/"reagiu", chame pausar imediatamente e mostre os suspeitos; se houver
  mais de um, use retestar com um número por vez e só então confirmar o que o usuário identificar.
- Nunca use permitir_servico sem pedido explícito do usuário."""


def _obj(props: dict, req: list | None = None, desc: str | None = None) -> dict:
    o = {"type": "object", "properties": props, "additionalProperties": False}
    if req:
        o["required"] = req
    if desc:
        o["description"] = desc
    return o


S = {"type": "string"}
I = {"type": "integer"}
N = {"type": "number"}
B = {"type": "boolean"}
VALOR = {"type": ["string", "number", "boolean"]}
MAPA_VALORES = {"type": "object", "additionalProperties": VALOR}
SAIDA = {"type": "object", "additionalProperties": True}
SO_LEITURA = {"readOnlyHint": True, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False}
EMITE = {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": True}
ALTERA = {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": True, "openWorldHint": False}

FERRAMENTAS = [
    {"name": "consultar", "title": "Consultar o controle do POCO",
     "description": "Estado do servidor e do emissor infravermelho, resumo do catálogo (categorias, marcas instaladas), "
                    "aparelhos salvos e busca em andamento. Use primeiro para testar a conexão.",
     "inputSchema": _obj({"categoria": dict(S, description="filtra as marcas por categoria (ex.: ar, tv, ventilador)"),
                          "marca": dict(S, description="filtra marcas que contêm este texto")}),
     "annotations": SO_LEITURA},
    {"name": "procurar_perfis", "title": "Procurar perfis no catálogo",
     "description": "Procura controles no catálogo por categoria, marca, modelo ou texto livre.",
     "inputSchema": _obj({"categoria": S, "marca": S, "modelo": S, "texto": S, "limite": I}),
     "annotations": SO_LEITURA},
    {"name": "opcoes", "title": "Capacidades de um aparelho",
     "description": "Parâmetros, valores aceitos, teclas, macros e últimos estados de um aparelho salvo (ou de um "
                    "perfil do catálogo). Consulte antes de controlar.",
     "inputSchema": _obj({"aparelho": dict(S, description="nome salvo, ex.: ar do quarto"),
                          "perfil": dict(I, description="id do perfil no catálogo")}),
     "annotations": SO_LEITURA},
    {"name": "controlar", "title": "Comandar um aparelho",
     "description": "Envia um pedido simples ou composto a um aparelho salvo. Consulta as capacidades, escolhe teclas "
                    "diretas, passos ou a configuração completa (ar-condicionado) e informa o que foi enviado. "
                    "Ex.: {aparelho:'ar do quarto', ligar:true, definir:{temperatura:23, modo:'frio', "
                    "ventilacao:'baixa'}}; {aparelho:'soundbar', ajustar:{volume:3}}; "
                    "{aparelho:'tv do quarto', definir:{entrada:'hdmi2'}}; {aparelho:'ar do quarto', ligar:false}.",
     "inputSchema": _obj({
         "aparelho": S,
         "ligar": dict(B, description="true liga, false desliga"),
         "definir": dict(MAPA_VALORES, description="valores absolutos: energia, temperatura, modo, ventilacao, "
                                                   "oscilacao, velocidade, entrada, cor, canal..."),
         "ajustar": {"type": "object", "additionalProperties": I,
                     "description": "passos relativos, ex.: {volume: 3} ou {brilho: -2}"},
         "teclas": {"type": "array", "items": {"anyOf": [S, _obj({"comando": S, "vezes": I}, ["comando"])]},
                    "description": "teclas avulsas pelo nome ou chave, em ordem"},
         "macro": dict(S, description="nome de uma macro salva no aparelho"),
         "repetir_ultimo": dict(B, description="repete o último pedido enviado a este aparelho"),
         "estado_atual": dict(MAPA_VALORES, description="estado físico informado pelo usuário agora"),
         "permitir_alternancia": dict(B, description="aceita enviar uma tecla que só alterna sem saber o estado"),
         "permitir_servico": dict(B, description="somente se o usuário pedir explicitamente um comando de serviço"),
         "simular": dict(B, description="só planeja, não transmite"),
     }, ["aparelho"]),
     "annotations": EMITE},
    {"name": "registrar_estado", "title": "Registrar o que aconteceu no aparelho",
     "description": "Guarda o estado físico observado pelo usuário (separado do último comando emitido). Use também "
                    "quando o usuário disser que mexeu no controle original.",
     "inputSchema": _obj({"aparelho": S, "estado": MAPA_VALORES, "controle_original_usado": B}, ["aparelho"]),
     "annotations": ALTERA},
    {"name": "buscar", "title": "Descobrir o controle por testes",
     "description": "Inicia no celular uma bateria de testes: envia um candidato a cada intervalo (padrão 8 s), em "
                    "lotes, priorizando marca/modelo/categoria. Categoria, marca e modelo são opcionais. "
                    "modo='teclas' descobre outras teclas de um aparelho já salvo (varredura=true também gera "
                    "comandos do mesmo endereço). continuar=true retoma a busca anterior.",
     "inputSchema": _obj({
         "categoria": S, "marca": S, "modelo": dict(S, description="modelo do aparelho ou do controle"),
         "pistas": dict(S, description="descrição livre, ex.: ventilador antigo de coluna"),
         "comando_teste": dict(S, description="função observável: energia (padrão), volume, cor, velocidade, "
                                              "mudo, canal, menu, disparo ou o nome de uma tecla"),
         "intervalo": dict(N, description="segundos entre testes (2–60)"),
         "lote": dict(I, description="testes por lote antes de parar para perguntar"),
         "modo": {"type": "string", "enum": ["perfis", "teclas"]},
         "aparelho": dict(S, description="aparelho salvo (modo teclas)"),
         "varredura": B,
         "apenas_marca": dict(B, description="padrão true: com marca instalada, testa só ela e as relacionadas"),
         "continuar": B}),
     "annotations": EMITE},
    {"name": "progresso", "title": "Progresso da busca",
     "description": "Candidato atual, quantos foram testados, histórico recente numerado e orientação.",
     "inputSchema": _obj({"ultimos": I}), "annotations": SO_LEITURA},
    {"name": "pausar", "title": "Pausar a busca agora",
     "description": "Pausa imediatamente e devolve os suspeitos: o último sinal e os enviados durante o tempo de "
                    "reação. Chame assim que o usuário disser que o aparelho reagiu.",
     "inputSchema": _obj({}), "annotations": ALTERA},
    {"name": "retomar", "title": "Retomar a busca",
     "description": "Continua do ponto em que parou (ou a_partir_de uma posição), opcionalmente com novo intervalo.",
     "inputSchema": _obj({"intervalo": N, "a_partir_de": I, "lote": I}), "annotations": EMITE},
    {"name": "retestar", "title": "Repetir tentativas",
     "description": "Reenvia tentativas do histórico pelo número. Para comparar suspeitos, envie um número por vez e "
                    "pergunte ao usuário o que aconteceu.",
     "inputSchema": _obj({"numeros": {"type": "array", "items": I}, "intervalo": N}, ["numeros"]),
     "annotations": EMITE},
    {"name": "confirmar", "title": "Confirmar o resultado de uma tentativa",
     "description": "Registra que a tentativa número N funcionou (ou não). Se vários perfis compartilham o sinal, "
                    "devolve testes de distinção com uma segunda função.",
     "inputSchema": _obj({"numero": I, "funcionou": B}, ["numero"]), "annotations": ALTERA},
    {"name": "distinguir", "title": "Enviar uma variante de distinção",
     "description": "Envia a variante (A, B, C...) de um teste de distinção proposto por confirmar.",
     "inputSchema": _obj({"teste": S, "variante": S}, ["teste", "variante"]), "annotations": EMITE},
    {"name": "salvar_aparelho", "title": "Salvar aparelho",
     "description": "Salva o resultado da busca (ou um perfil do catálogo) com um nome em português. "
                    "somente_confirmado=true salva só as teclas que funcionaram.",
     "inputSchema": _obj({"nome": S, "perfil": I, "somente_confirmado": B, "categoria": S, "substituir": B,
                          "funcao": dict(S, description="nome da função confirmada, se não for a de teste")},
                         ["nome"]),
     "annotations": ALTERA},
    {"name": "editar_aparelho", "title": "Editar aparelho",
     "description": "Renomeia, adiciona tecla (do histórico, sinal bruto, texto ou outro perfil), remove ou renomeia "
                    "comandos, define faixas (ex.: velocidade min 1 max 3), cria macros, troca o perfil ou exclui.",
     "inputSchema": _obj({
         "aparelho": S, "renomear": S,
         "adicionar_comando": _obj({"nome": S, "funcao": S, "numero": I, "conteudo": S, "sinal": SAIDA,
                                    "de_perfil": I, "comando": S}),
         "remover_comando": S, "renomear_comando": _obj({"de": S, "para": S}),
         "faixas": {"type": "object", "additionalProperties": {"type": ["object", "null"]}},
         "macro": _obj({"nome": S, "descricao": S, "passos": {"type": "array", "items": SAIDA}}),
         "remover_macro": S, "trocar_perfil": I,
         "configuracao": _obj({"intervalo_teclas": N, "espera_apos_ligar": N}),
         "excluir": B}, ["aparelho"]),
     "annotations": {**ALTERA, "destructiveHint": True}},
    {"name": "importar", "title": "Importar perfil ou sinal",
     "description": "Importa .ir do Flipper, JSON do SmartIR, perfil do controle-ir, Pronto, Broadlink base64 ou sinal "
                    "bruto (frequência + pulsos). destino='catalogo' (padrão) ou 'aparelho'.",
     "inputSchema": _obj({"conteudo": S, "nome": S, "categoria": S, "marca": S, "modelo": S,
                          "destino": {"type": "string", "enum": ["catalogo", "aparelho"]}, "aparelho": S},
                         ["conteudo"]),
     "annotations": ALTERA},
    {"name": "exportar", "title": "Exportar perfil",
     "description": "Exporta um aparelho salvo ou perfil do catálogo em json, flipper (.ir) ou pronto.",
     "inputSchema": _obj({"aparelho": S, "perfil": I, "formato": {"type": "string", "enum": ["json", "flipper", "pronto"]}}),
     "annotations": SO_LEITURA},
    {"name": "enviar_sinal", "title": "Enviar um sinal bruto",
     "description": "Transmite um sinal avulso (ex.: capturado por um receptor externo) para teste.",
     "inputSchema": _obj({"sinal": dict(SAIDA, description="{frequencia, pulsos} ou {protocolo, endereco, comando}"),
                          "conteudo": dict(S, description="texto: Pronto, Broadlink, '38000: 9000 4500 ...'"),
                          "vezes": I}),
     "annotations": EMITE},
]
for _f in FERRAMENTAS:
    _f["outputSchema"] = SAIDA

_ARGS = {f["name"]: set(f["inputSchema"]["properties"]) for f in FERRAMENTAS}


class ServidorMCP:
    def __init__(self, servico: Servico, log=None):
        self.servico = servico
        self.log = log or (lambda *a: None)

    def tratar(self, corpo) -> tuple[int, object | None]:
        """Recebe o JSON decodificado; devolve (status HTTP, resposta JSON ou None)."""
        if isinstance(corpo, list):
            respostas = [r for r in (self._uma(m) for m in corpo) if r is not None]
            return (200, respostas) if respostas else (202, None)
        r = self._uma(corpo)
        return (200, r) if r is not None else (202, None)

    def _erro(self, ident, codigo, msg):
        return {"jsonrpc": "2.0", "id": ident, "error": {"code": codigo, "message": msg}}

    def _uma(self, msg):
        if not isinstance(msg, dict) or msg.get("jsonrpc") != "2.0":
            return self._erro(msg.get("id") if isinstance(msg, dict) else None, -32600, "requisição inválida")
        metodo = msg.get("method")
        ident = msg.get("id")
        if metodo is None:
            return None  # resposta do cliente a algo nosso: ignorar
        if ident is None:
            return None  # notificação (initialized, cancelled...)
        params = msg.get("params") or {}
        try:
            if metodo == "initialize":
                pedida = params.get("protocolVersion")
                versao = pedida if pedida in VERSOES else VERSOES[0]
                return {"jsonrpc": "2.0", "id": ident, "result": {
                    "protocolVersion": versao,
                    "capabilities": {"tools": {"listChanged": False}},
                    "serverInfo": {"name": "controle-ir", "title": "Controle do POCO", "version": __version__},
                    "instructions": INSTRUCOES}}
            if metodo == "ping":
                return {"jsonrpc": "2.0", "id": ident, "result": {}}
            if metodo == "tools/list":
                return {"jsonrpc": "2.0", "id": ident, "result": {"tools": FERRAMENTAS}}
            if metodo == "tools/call":
                return {"jsonrpc": "2.0", "id": ident, "result": self.chamar(params.get("name"),
                                                                              params.get("arguments") or {})}
            if metodo in ("resources/list", "prompts/list"):
                chave = "resources" if metodo.startswith("resources") else "prompts"
                return {"jsonrpc": "2.0", "id": ident, "result": {chave: []}}
            return self._erro(ident, -32601, f"método não suportado: {metodo}")
        except Exception as e:  # noqa: BLE001
            self.log("erro interno", traceback.format_exc())
            return self._erro(ident, -32603, f"erro interno: {e}")

    def chamar(self, nome: str, args: dict) -> dict:
        if nome not in _ARGS:
            return self._resultado({"erro": f"ferramenta desconhecida: {nome}"}, True)
        desconhecidos = set(args) - _ARGS[nome]
        args = {k: v for k, v in args.items() if k in _ARGS[nome]}
        self.log(f"ferramenta {nome}", json.dumps(args, ensure_ascii=False)[:300])
        try:
            r = getattr(self.servico, nome)(**args)
            if desconhecidos:
                r = dict(r, argumentos_ignorados=sorted(desconhecidos))
            return self._resultado(r, False)
        except ErroUso as e:
            return self._resultado({"erro": str(e)}, True)
        except TypeError as e:
            return self._resultado({"erro": f"argumentos inválidos: {e}"}, True)
        except Exception as e:  # noqa: BLE001
            self.log("falha na ferramenta", traceback.format_exc())
            return self._resultado({"erro": f"falha inesperada: {e}"}, True)

    @staticmethod
    def _resultado(dados: dict, erro: bool) -> dict:
        texto = json.dumps(dados, ensure_ascii=False, default=str)
        return {"content": [{"type": "text", "text": texto}], "structuredContent": json.loads(texto),
                "isError": erro}
