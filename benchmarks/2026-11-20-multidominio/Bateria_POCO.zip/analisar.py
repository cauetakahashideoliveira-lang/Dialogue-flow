"""Recalcula os indicadores e gera CSV e relatório a partir dos registros da rodada."""
from pathlib import Path
from statistics import median
from html import escape
import csv, json, math, re
P=Path(__file__).resolve().parent
def read(n):return json.loads((P/n).read_text())
def rows(n):return [json.loads(s) for s in (P/n).read_text().splitlines() if s.strip()]
def csvout(n,rs):
    with (P/n).open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
def p95(a):return sorted(a)[math.ceil(.95*len(a))-1]
def seg(x):return f"{x/1000:.2f}".replace(".",",")+" s"
def table(header,rs):
    return '<table><thead><tr>'+''.join('<th>'+escape(str(x))+'</th>' for x in header)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+escape(str(x))+'</td>' for x in row)+'</tr>' for row in rs)+'</tbody></table>'
cases={x['id']:x for x in read('raciocinio_casos.json')}
model=[]
for path,modo in [('sonnet.jsonl','livre'),('sonnet_schema.jsonl','schema')]:
    for r in rows(path):
        c=cases[r['id']]
        # Separado do critério principal. Aceita apenas um objeto inequívoco e do tipo esperado.
        matches=re.findall(r'\{\s*"resposta"\s*:[^{}]+\}',r.get('texto',''))
        extraidos=[json.loads(m)['resposta'] for m in matches]
        value_ok=len(extraidos)==1 and extraidos[0]==c['esperado'] and type(extraidos[0]) is type(c['esperado'])
        model.append(dict(caso=r['id'],familia=c['familia'],esforco=r['esforco'],formato=modo,
            semantico=value_ok,estrito=r['acerto'],ms=r['ms'],entrada=r['uso']['input_tokens'],saida=r['uso']['output_tokens'],
            esperado=json.dumps(c['esperado'],ensure_ascii=False),resposta=r['texto']))
csvout("raciocinio.csv",model)
summary=[]
for nivel,modo in [('medium','livre'),('high','livre'),('high','schema')]:
    sub=[r for r in model if r['esforco']==nivel and r['formato']==modo]
    t=[r['ms'] for r in sub]
    summary.append([nivel+' / '+modo,len(sub),sum(r['semantico'] for r in sub),sum(r['estrito'] for r in sub),seg(median(t)),seg(p95(t)),sum(r['entrada'] for r in sub),sum(r['saida'] for r in sub)])
chess=rows("xadrez.jsonl"); chess_table=[];mov=[]
for b in [50,200,500]:
    sub=[r for r in chess if r['orcamento']==b]
    lances=[m for r in sub for m in r['lances']]
    chess_table.append([b,sum(r['acerto'] for r in sub),sum(r['lances'][0]['acerto'] for r in sub),len(lances),seg(sum(x['ms'] for x in lances)),f"{sum(x['nos'] for x in lances):,}".replace(","," ")])
    for r in sub:
        for i,m in enumerate(r['lances'],1):
            mov.append(dict(id=r['id'],rating=r['rating'],orcamento_ms=b,decisao=i,**m))
csvout("xadrez_lances.csv",mov)
auto=sorted([json.loads(x.read_text()) for x in (P/'autonomia').glob('*.json')],key=lambda x:int(x['id'][1:]))
csvout("autonomia.csv",[dict(id=r['id'],pedido=r['pedido'],esperado=" > ".join(r['esperado']),executado=" > ".join(o['ferramenta'] for o in r['operacoes']),estado=r['estado'],acerto=r['acerto'],ms=r['ms'],motivo=r['motivo']) for r in auto])
ui=rows('calculadora.jsonl')
for r in ui:
    assert any(re.search(r'^"=\s*'+str(r['esperado'])+r'"\s+#result\b',s) for s in r['recibo'])
csvout("calculadora.csv",[dict(id=r['id'],modo=r['modo'],expressao=r['expressao'],esperado=r['esperado'],ms=r['ms'],acoes_s=r['tempos']['acoes'],olhar_s=r['tempos']['olhar'],acerto=r['acerto']) for r in ui])
ui_table=[]
for modo in ['rótulos','coordenadas']:
    sub=[r for r in ui if r['modo']==modo]
    ui_table.append([modo,sum(r['acerto'] for r in sub),seg(median(r['ms'] for r in sub)),seg(1000*median(r['tempos']['acoes'] for r in sub))])
assert len(model)==54 and len(chess)==72 and len(auto)==10 and len(ui)==6
body=[
'<p class="eyebrow">POCO X8 Pro Max · 20 de novembro de 2026</p><h1>O que limita a autonomia do POCO?</h1>',
'<p class="lead">O Sonnet acertou o conteúdo dos 18 problemas nos três perfis. O que mais variou foi a capacidade de entregar uma resposta utilizável. Nas missões reais, quatro pedidos viáveis terminaram antes da primeira operação.</p>',
'<p><strong>142 execuções pontuadas</strong> em 55 casos distintos. São 54 respostas de raciocínio, 10 missões reais, 6 operações de calculadora e 72 tentativas de xadrez. Cada grupo tem seu próprio critério. As taxas não foram somadas em uma nota geral.</p>',
'<h2>Raciocínio e formato de saída</h2><p>Os 18 casos cobrem deduplicação e agregação de dados, agendamento, rotas e dependências, otimização com restrições, suficiência de evidência e conversão de unidades. O aparelho enviou cada pergunta à API do Claude Sonnet 5.5 sem o gabarito. Cada combinação de caso e perfil foi executada uma vez. As duas condições livres alternaram de ordem entre casos. O reteste com esquema ocorreu depois.</p>',
table(['Esforço / formato','Casos','Valor correto','JSON direto e correto','Mediana','P95','Tokens entrada','Tokens saída'],summary),
'<p><strong>Leitura do resultado.</strong> O critério primário exigia um objeto JSON com uma única chave, tipo correto e valor exato. Para medir conteúdo separadamente, uma segunda avaliação procurou um único objeto inequívoco dentro da resposta. Explicações e blocos de código explicam as perdas no critério estrito. O esquema foi igual para os 18 casos e aceitava vários tipos de resposta, sem revelar o valor correto.</p>',
'<p>Com esforço alto, o esquema passou de 7 para 18 respostas diretamente utilizáveis. A mediana subiu cerca de 0,04 s. Os tokens de saída caíram de 1.999 para 1.166, e os de entrada subiram de 2.340 para 7.416. Não foi medido custo financeiro. O acerto de conteúdo atingiu o teto desta amostra, o que impede distinguir a capacidade de raciocínio dos dois níveis de esforço.</p>',
'<h2>Autonomia na missão instalada</h2><p>Uma chamada externa por objetivo, com seleção e execução no POCO. O gabarito exigiu ordem correta, ausência de chamadas extras e recibo de execução. Nos pedidos inviáveis, exigiu interrupção sem executar ferramentas. Foram 4 sucessos em 8 pedidos viáveis e 2 interrupções corretas em 2 pedidos inviáveis. Mediana de ponta a ponta para as 10 missões: 5,30 s. Recibos de política preservam apenas nomes de campos.</p>',
table(['Caso','Pedido','Ferramentas executadas','Tempo','Critério'],[[r['id'],r['pedido'],', '.join(o['ferramenta'] for o in r['operacoes']) or 'nenhuma',seg(r['ms']),'passou' if r['acerto'] else 'falhou'] for r in auto]),
'<p>A2, A3, A9 e A10 pararam antes de executar qualquer ferramenta. A5 conseguiu consultar política e capacidades na mesma missão. Isso mostra que as ferramentas estavam acessíveis na bateria. O recibo de interrupção não diferencia plano vazio de falha de interpretação do formato. A causa de cada interrupção permanece em aberto.</p>',
'<h2>Operação da interface real</h2><p>Calculadora Xiaomi, mesma disposição dos controles. Foram repetidas três expressões pelos dois métodos: 17 × 23 = 391, 144 ÷ 12 = 12 e 702 − 465 = 237. Em todos os casos foi conferido o campo do resultado atual. Histórico foi excluído da conferência. Cada sequência foi preparada pelo chat e executada em lote no aparelho. É uma medida de execução da interface.</p>',
table(['Método','Acertos / 3','Mediana ponta a ponta','Mediana das ações no POCO'],ui_table),
'<p>As coordenadas venceram por tempo nas três comparações pareadas. A vantagem depende da posição estável dos botões. A amostra não avalia rotação, mudança de aplicativo ou acessibilidade em outros layouts.</p>',
'<h2>Tática de xadrez</h2><p>Stockfish 19 no aparelho, 2 threads e hash de 64 MiB. Amostra fixa de 24 problemas Lichess, oito por faixa de rating (900–1.499, 1.500–2.099 e 2.100–3.400). O primeiro lance do arquivo posiciona o problema; apenas as decisões seguintes do jogador foram avaliadas. As continuações do adversário são as do gabarito. Aceita-se uma alternativa que já dê mate. A tentativa termina no primeiro desvio. Uma continuação alternativa forte sem mate imediato pode ser reprovada por este critério.</p>',
table(['Orçamento por lance (ms)','Linha completa / 24','Primeiro lance / 24','Decisões','Tempo de busca total','Nós explorados'],chess_table),
'<p>O único desvio a 50 ms foi no problema 01OKT. Com 200 e 500 ms, os mesmos 24 problemas passaram. O teste mede busca no motor, sem leitura de tela ou toques. Não mede Elo, força contra pessoas, consumo de bateria nem joules.</p>',
'<h2>Próxima rodada de otimização</h2>',
table(['Prioridade','Mudança em teste','Desenho e critério de avanço proposto'],[
['1 · Planejador','Validar por esquema a lista de operações. Registrar “plano vazio”, “resposta inválida”, “ferramenta indisponível” e “execução falhou” separadamente.','Comparar a versão atual e a candidata em 40 objetivos inéditos (30 viáveis, 10 impossíveis), duas repetições por versão com ordem alternada. Avançar com ≥54/60 viáveis corretos, 20/20 interrupções apropriadas e zero ação extra.'],
['2 · Raciocínio','Com esquema fixo, comparar médio e alto em casos difíceis e inéditos.','60 casos, 10 por família, duas repetições por perfil. Incluir dados contraditórios, restrições que quase conflitam e respostas insuficientes. Pontuar valor, formato, latência e tokens; escolher médio só se perder no máximo 2 pontos percentuais e reduzir a latência mediana em pelo menos 10%.'],
['3 · Interface','Usar coordenadas em lote quando a disposição for reconhecida e reancorar por rótulos após mudança.','30 pares em três layouts, com interrupções e rotação. Exigir nenhum toque no controle errado; mediana local pelo menos 15% menor que a dos rótulos.'],
['4 · Xadrez','Manter 200 ms como referência provisória; testar 50 e 100 ms e um orçamento adaptativo.','120 problemas inéditos estratificados, com mais linhas longas e difíceis. Comparar pares, tempo e nós. Avançar se mantiver a taxa da referência dentro de 2 pontos percentuais e reduzir a busca total em pelo menos 25%.']]),
'<h2>Como repetir e interpretar</h2><p>Os JSONL são os registros por tentativa. Os CSV trazem as medidas derivadas, e os arquivos de casos preservam os estímulos e gabaritos. O arquivo rodar.py roda o motor e os problemas de raciocínio; o README detalha a repetição das missões e da calculadora. A análise usa mediana convencional e percentil por posto superior. Com 18 observações, P95 por esse método é o máximo observado.</p>',
'<p>As latências do Sonnet incluem rede e API, medidas no POCO. As de missão e calculadora incluem a ida e volta pelo conector. As buscas do Stockfish foram cronometradas no aparelho. Uma observação por caso e condição, ordem parcialmente controlada e um único aparelho limitam a generalização. A perda inicial de conexão foi anterior à série pontuada. A disponibilidade do conector exige uma série de medições própria.</p>',
'<p>Fontes: <a href="https://database.lichess.org/">base de problemas e convenção de lances</a>, <a href="https://github.com/aKevinM/Lichess-Puzzles-Analysis/blob/main/lichess_db_puzzle_sample.csv">amostra pública</a>, <a href="https://platform.claude.com/docs/en/build-with-claude/structured-outputs">formato estruturado</a>, <a href="https://github.com/cauetakahashideoliveira-lang/Dialogue-flow/pull/19">implementação do planejador</a>.</p>'
]
css='body{max-width:1040px;margin:45px auto;padding:0 24px 60px;color:#152e39;background:#fafbf9;font:16px/1.52 system-ui,sans-serif}h1{font-size:clamp(32px,4vw,48px);line-height:1.05;margin:12px 0 20px}h2{margin-top:38px;color:#126664}p{max-width:91ch}.eyebrow{color:#27736b;font-weight:650}.lead{font-size:21px}table{border-collapse:collapse;width:100%;background:white;font-size:14px}td,th{padding:9px;text-align:left;border-bottom:1px solid #d7e1dc;vertical-align:top}th{background:#144a4d;color:white}a{color:#00635e}@media print{body{margin:0}tr{break-inside:avoid}}'
(P/'Relatorio.html').write_text('<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Bateria de desempenho do POCO</title><style>'+css+'</style><main>'+''.join(body)+'</main></html>')
